public class Rummikub {
  public static void main(String[] args){





  }
}
